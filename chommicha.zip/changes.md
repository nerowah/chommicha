### Ljadid

- Auto synced skins with champion selection and stuff Hadchis still for test dyal room thing
- Auto delete auto-selected skins
- tzad random skin mn favourites 

- Special skins not showing (Immortalized Ahri for example)
- Filter Db khdam (khdmtona lay 3tikom lhwa )